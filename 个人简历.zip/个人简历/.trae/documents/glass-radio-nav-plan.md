# Glass Radio Navigation Plan

## Context
The user wants to replace the current PillNav navigation buttons (首页、亮点、经历、项目、技能、教育) with a UIverse-style glass radio group. The provided UIverse snippet only has 3 colors (Silver/Gold/Platinum), but we need 6 items, so the design must be extended to 6 metallic glass colors while preserving the same visual language.

## What has already been changed
- CSS: `.pill-nav-*` styles replaced with `.glass-nav-bar`, `.glass-radio-group`, `.glass-glider`, and 6 color variants.
- HTML: navigation markup replaced with 6 radio inputs + labels + a shared glider.
- Print styles: updated to hide `.glass-nav-bar`.

## Remaining change
Update the JavaScript in `index.html`:
- Remove `initPillNav()`, `initMenu()`, and the old `initActiveNav()`.
- Add `initGlassNav()` that:
  1. Reads the radio group (`#glassNav`) and labels with `data-color`.
  2. On radio change, smoothly scrolls to the target section and moves/glides the `.glass-glider` to the active item with the matching metallic color.
  3. On window scroll, syncs the checked radio to the currently visible section (threshold ~140px).
  4. Handles resize by recalculating glider position.
- Update the `init()` call list to call `initGlassNav()` instead of `initPillNav(); initMenu(); initActiveNav();`.

## Critical file
- `c:\Users\zzz\Desktop\个人简历\index.html`

## Verification
1. Open `index.html` in a browser.
2. Verify the top bar shows six glass pills with a sliding colored glider.
3. Click each pill: it should scroll to the corresponding section and the glider should slide + change color.
4. Scroll manually: the glider should follow the currently visible section.
5. Verify mobile layout is usable (horizontal scroll area if needed).
